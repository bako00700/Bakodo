import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

import '../models/memory_item.dart';
import '../services/storage_service.dart';
import '../services/ai_service.dart';
import '../utils/app_theme.dart';

class AddMemoryScreen extends StatefulWidget {
  final MemoryItem? existing;
  const AddMemoryScreen({super.key, this.existing});

  @override
  State<AddMemoryScreen> createState() => _AddMemoryScreenState();
}

class _AddMemoryScreenState extends State<AddMemoryScreen> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  String _type = 'text';
  String? _imagePath;
  String? _filePath;
  DateTime? _reminderDate;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    if (widget.existing != null) {
      final e = widget.existing!;
      _titleController.text = e.title;
      _contentController.text = e.content;
      _type = e.type;
      _imagePath = e.imagePath;
      _filePath = e.filePath;
      _reminderDate = e.reminderDate;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _imagePath = image.path;
        _type = 'image';
      });
    }
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.camera);
    if (image != null) {
      setState(() {
        _imagePath = image.path;
        _type = 'image';
      });
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx', 'txt'],
    );
    if (result != null && result.files.single.path != null) {
      setState(() {
        _filePath = result.files.single.path;
        _type = 'document';
        if (_titleController.text.isEmpty) {
          _titleController.text = result.files.single.name;
        }
      });
    }
  }

  Future<void> _pickReminderDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
      locale: const Locale('ar'),
    );
    if (date == null) return;

    if (!mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (time == null) return;

    setState(() {
      _reminderDate = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
      _type = 'reminder';
    });
  }

  Future<void> _save() async {
    if (_contentController.text.trim().isEmpty &&
        _imagePath == null &&
        _filePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أضف محتوى على الأقل')),
      );
      return;
    }

    setState(() => _isSaving = true);

    final storage = context.read<StorageService>();
    final ai = context.read<AiService>();

    // تحليل المحتوى بالذكاء الاصطناعي
    final analysis = await ai.analyzeContent(_contentController.text);

    final item = MemoryItem(
      id: widget.existing?.id,
      title: _titleController.text.trim().isEmpty
          ? (analysis['summary'] as String? ?? 'ذكرى جديدة')
          : _titleController.text.trim(),
      content: _contentController.text.trim(),
      type: _type,
      imagePath: _imagePath,
      filePath: _filePath,
      reminderDate: _reminderDate,
      summary: analysis['summary'] as String?,
      tags: List<String>.from(analysis['tags'] ?? []),
      category: analysis['category'] as String?,
      entities: List<String>.from(analysis['entities'] ?? []),
      createdAt: widget.existing?.createdAt,
    );

    if (widget.existing != null) {
      await storage.updateMemory(item);
    } else {
      await storage.addMemory(item);
    }

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.existing != null ? 'تم التحديث' : 'تم الحفظ بنجاح'),
          backgroundColor: Colors.green.shade600,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final ai = context.watch<AiService>();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing != null ? 'تعديل ذكرى' : 'إضافة ذكرى'),
        actions: [
          if (_isSaving || ai.isProcessing)
            const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          else
            TextButton(
              onPressed: _save,
              child: const Text(
                'حفظ',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // أزرار الإضافة السريعة
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _TypeButton(
                  icon: Icons.camera_alt_rounded,
                  label: 'كاميرا',
                  onTap: _takePhoto,
                  selected: _type == 'image' && _imagePath != null,
                ),
                _TypeButton(
                  icon: Icons.image_rounded,
                  label: 'صورة',
                  onTap: _pickImage,
                  selected: _type == 'image',
                ),
                _TypeButton(
                  icon: Icons.attach_file_rounded,
                  label: 'ملف',
                  onTap: _pickFile,
                  selected: _type == 'document',
                ),
                _TypeButton(
                  icon: Icons.alarm_rounded,
                  label: 'تذكير',
                  onTap: _pickReminderDate,
                  selected: _type == 'reminder',
                ),
              ],
            ),
            const SizedBox(height: 24),

            // معاينة الصورة
            if (_imagePath != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(
                  File(_imagePath!),
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 16),
            ],

            // معاينة الملف
            if (_filePath != null) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.description, color: Colors.orange),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _filePath!.split('/').last,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ],

            // تاريخ التذكير
            if (_reminderDate != null) ...[
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.alarm, color: AppTheme.accent),
                    const SizedBox(width: 12),
                    Text(
                      'تذكير: ${_reminderDate!.day}/${_reminderDate!.month}/${_reminderDate!.year} '
                      '${_reminderDate!.hour.toString().padLeft(2, '0')}:'
                      '${_reminderDate!.minute.toString().padLeft(2, '0')}',
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ],

            // العنوان
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'العنوان (اختياري)',
                hintText: 'مثال: موعد الدكتور',
              ),
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 16),

            // المحتوى
            TextField(
              controller: _contentController,
              decoration: const InputDecoration(
                labelText: 'المحتوى',
                hintText: 'اكتب ما تريد تذكره...',
                alignLabelWithHint: true,
              ),
              maxLines: 8,
              minLines: 5,
            ),
            const SizedBox(height: 24),

            // زر الحفظ الكبير
            ElevatedButton.icon(
              onPressed: _isSaving || ai.isProcessing ? null : _save,
              icon: ai.isProcessing
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.check_rounded),
              label: Text(
                ai.isProcessing ? 'جاري التحليل...' : 'حفظ الذكرى',
              ),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TypeButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool selected;

  const _TypeButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 72,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected
              ? AppTheme.primary.withOpacity(0.15)
              : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(16),
          border: selected
              ? Border.all(color: AppTheme.primary, width: 1.5)
              : null,
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: selected ? AppTheme.primary : Colors.grey.shade600,
              size: 28,
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: selected ? AppTheme.primary : Colors.grey.shade600,
                fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
