import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

part 'memory_item.g.dart';

@HiveType(typeId: 0)
class MemoryItem extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String content;

  @HiveField(3)
  final DateTime createdAt;

  @HiveField(4)
  DateTime updatedAt;

  @HiveField(5)
  String type; // text, image, document, voice, reminder

  @HiveField(6)
  List<String> tags;

  @HiveField(7)
  String? imagePath;

  @HiveField(8)
  String? filePath;

  @HiveField(9)
  String? audioPath;

  @HiveField(10)
  DateTime? reminderDate;

  @HiveField(11)
  bool isReminderDone;

  @HiveField(12)
  String? summary; // ملخص من الذكاء الاصطناعي

  @HiveField(13)
  List<String> entities; // كيانات مستخرجة (أشخاص، أماكن...)

  @HiveField(14)
  String? category;

  MemoryItem({
    String? id,
    required this.title,
    required this.content,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.type = 'text',
    List<String>? tags,
    this.imagePath,
    this.filePath,
    this.audioPath,
    this.reminderDate,
    this.isReminderDone = false,
    this.summary,
    List<String>? entities,
    this.category,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now(),
        tags = tags ?? [],
        entities = entities ?? [];

  MemoryItem copyWith({
    String? title,
    String? content,
    DateTime? updatedAt,
    String? type,
    List<String>? tags,
    String? imagePath,
    String? filePath,
    String? audioPath,
    DateTime? reminderDate,
    bool? isReminderDone,
    String? summary,
    List<String>? entities,
    String? category,
  }) {
    return MemoryItem(
      id: id,
      title: title ?? this.title,
      content: content ?? this.content,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      type: type ?? this.type,
      tags: tags ?? this.tags,
      imagePath: imagePath ?? this.imagePath,
      filePath: filePath ?? this.filePath,
      audioPath: audioPath ?? this.audioPath,
      reminderDate: reminderDate ?? this.reminderDate,
      isReminderDone: isReminderDone ?? this.isReminderDone,
      summary: summary ?? this.summary,
      entities: entities ?? this.entities,
      category: category ?? this.category,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'content': content,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'type': type,
        'tags': tags,
        'imagePath': imagePath,
        'filePath': filePath,
        'audioPath': audioPath,
        'reminderDate': reminderDate?.toIso8601String(),
        'isReminderDone': isReminderDone,
        'summary': summary,
        'entities': entities,
        'category': category,
      };
}
