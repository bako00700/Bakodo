import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

/// خدمة الذكاء الاصطناعي
/// حالياً تعمل بشكل تجريبي (Mock).
/// لربطها بـ OpenAI أو Gemini: ضع مفتاح API في الإعدادات.
class AiService extends ChangeNotifier {
  bool _isProcessing = false;
  bool get isProcessing => _isProcessing;

  // ضع مفتاحك هنا أو في شاشة الإعدادات
  String? apiKey;
  String provider = 'mock'; // mock | openai | gemini

  Future<Map<String, dynamic>> analyzeContent(String content) async {
    _isProcessing = true;
    notifyListeners();

    try {
      if (provider == 'mock' || apiKey == null || apiKey!.isEmpty) {
        // محاكاة ذكية للتجربة
        await Future.delayed(const Duration(milliseconds: 800));
        return _mockAnalysis(content);
      }

      if (provider == 'openai') {
        return await _callOpenAI(content);
      } else if (provider == 'gemini') {
        return await _callGemini(content);
      }

      return _mockAnalysis(content);
    } finally {
      _isProcessing = false;
      notifyListeners();
    }
  }

  Map<String, dynamic> _mockAnalysis(String content) {
    final words = content.split(RegExp(r'\s+'));
    final summary = words.length > 20
        ? '${words.take(15).join(' ')}...'
        : content;

    // استخراج كلمات مفتاحية بسيطة
    final tags = <String>[];
    if (content.contains('عمل') || content.contains('مكتب')) tags.add('عمل');
    if (content.contains('عائلة') || content.contains('أطفال')) tags.add('عائلة');
    if (content.contains('صحة') || content.contains('دكتور')) tags.add('صحة');
    if (content.contains('سفر') || content.contains('رحلة')) tags.add('سفر');
    if (content.contains('مالية') || content.contains('فلوس') || content.contains('راتب')) {
      tags.add('مالية');
    }
    if (tags.isEmpty) tags.add('عام');

    String category = 'عام';
    if (tags.contains('عمل')) category = 'عمل';
    else if (tags.contains('عائلة')) category = 'عائلة';
    else if (tags.contains('صحة')) category = 'صحة';
    else if (tags.contains('سفر')) category = 'سفر';
    else if (tags.contains('مالية')) category = 'مالية';

    return {
      'summary': summary,
      'tags': tags,
      'category': category,
      'entities': [],
    };
  }

  Future<Map<String, dynamic>> _callOpenAI(String content) async {
    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'model': 'gpt-4o-mini',
        'messages': [
          {
            'role': 'system',
            'content': '''أنت مساعد ذكي لتطبيق "ذاكرتي". 
حلل النص التالي وأرجع JSON فقط بهذا الشكل:
{
  "summary": "ملخص قصير بالعربية",
  "tags": ["وسم1", "وسم2"],
  "category": "فئة واحدة",
  "entities": ["اسم شخص أو مكان أو تاريخ"]
}'''
          },
          {'role': 'user', 'content': content}
        ],
        'temperature': 0.3,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final text = data['choices'][0]['message']['content'];
      // محاولة استخراج JSON
      final jsonMatch = RegExp(r'\{[\s\S]*\}').firstMatch(text);
      if (jsonMatch != null) {
        return jsonDecode(jsonMatch.group(0)!);
      }
    }
    return _mockAnalysis(content);
  }

  Future<Map<String, dynamic>> _callGemini(String content) async {
    final url =
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey';
    final response = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {
                'text': '''حلل النص التالي وأرجع JSON فقط:
{
  "summary": "ملخص قصير بالعربية",
  "tags": ["وسم1", "وسم2"],
  "category": "فئة واحدة",
  "entities": ["اسم شخص أو مكان"]
}

النص:
$content'''
              }
            ]
          }
        ]
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final text = data['candidates'][0]['content']['parts'][0]['text'];
      final jsonMatch = RegExp(r'\{[\s\S]*\}').firstMatch(text);
      if (jsonMatch != null) {
        return jsonDecode(jsonMatch.group(0)!);
      }
    }
    return _mockAnalysis(content);
  }

  /// بحث دلالي بسيط (يمكن تطويره لاحقاً بـ Embeddings)
  Future<List<String>> semanticSearch(String query, List<String> contents) async {
    // في النسخة الحقيقية: حوّل الاستعلام والمحتويات إلى embeddings وقارن
    await Future.delayed(const Duration(milliseconds: 300));
    final q = query.toLowerCase();
    return contents
        .where((c) => c.toLowerCase().contains(q))
        .toList();
  }
}
